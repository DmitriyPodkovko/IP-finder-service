class PoolDoesNotExist(Exception):
    pass
